from flask import Flask, request, jsonify, render_template,jsonify
import joblib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.metrics.pairwise import cosine_similarity
import neattext.functions as nfx
from sklearn.metrics.pairwise import linear_kernel
import warnings
warnings.filterwarnings("ignore")
import json

data = joblib.load(open("data.joblib","rb"))
dump=joblib.load(open("data.joblib","rb"))
similarity_scores = joblib.load(open("cos.joblib","rb"))
course_title=joblib.load(open("course_title.joblib","rb"))

app = Flask(__name__)

# Create the app object

# Define predict function


@app.route('/')
def home():
    return render_template('index.html',
                           course_title=list(data['course_title'].values),
                           url=list(data['url'].values))
                           


@app.route('/recommend')
def recommend_ui():
    return render_template('recommend.html')


@app.route('/recommend_course', methods=['POST'])
def recommend():
    user_input = request.form.get('user_input')
    # index fetch
    index = np.where(data['course_title'] == user_input)[0][0]
    similar_items = sorted(list(enumerate(similarity_scores[index])), key=lambda x: x[1], reverse=True)[1:11]
    df = []
    for i in similar_items:
        item = []
        #print([(data['course_title'].iloc[i[0]]), i[1]])
        #item.append(data['course_title'].iloc[i[0]])
        #item.append(data['url'].iloc[i[0]])
        #item.append(i[1])
        
        
        #return (item)
        #df.append(item)
        #df=df['course_title','url','score']
        #df=df.head(10)
        print([(data['course_title'].iloc[i[0]]),i[1]])
        select_course_index=[i[0]]
        selected_course_score = [i[1]]
        rec_df =data.iloc[select_course_index] 
        rec_df['Similarity_Score'] = [i[1]]
        final_recommended_courses = rec_df[['course_title','url']] #
    
        final_recommended_courses=final_recommended_courses.head(10)
        #item.extend(list(final_recommended_courses['course_title'].values))
        #item.extend(list(final_recommended_courses['url'].values))
        #item.extend(list(final_recommended_courses['Similarity_Score'].values))
        item.extend(final_recommended_courses['course_title'])
        item.extend(final_recommended_courses['url'])
        
        
        #return (item)           
        
        df.append(item)
    return(df)
    return render_template('recommend.html', prediction_text=df)


if __name__ == "__main__":
    app.run(debug=True)
